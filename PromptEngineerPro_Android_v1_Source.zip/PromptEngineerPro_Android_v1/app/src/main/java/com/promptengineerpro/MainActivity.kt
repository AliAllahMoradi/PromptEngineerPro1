package com.promptengineerpro

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.launch
import org.json.JSONArray

private val ComponentActivity.dataStore by preferencesDataStore(name = "prompt_engineer_pro")
private val SAVED_PROMPTS = stringPreferencesKey("saved_prompts")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PromptEngineerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromptEngineerApp() {
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val scope = rememberCoroutineScope()
    var raw by remember { mutableStateOf("") }
    var domain by remember { mutableStateOf("الکترونیک و طراحی PCB") }
    var depth by remember { mutableStateOf("عمیق و مهندسی") }
    var ambiguity by remember { mutableStateOf("اگر ابهام مهمی وجود داشت، قبل از اجرا سؤال کن") }
    var extra by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(listOf<String>()) }
    var showSaved by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        activity.dataStore.data.collect { prefs ->
            val json = prefs[SAVED_PROMPTS] ?: "[]"
            saved = runCatching {
                val arr = JSONArray(json)
                (0 until arr.length()).map { arr.getString(it) }
            }.getOrDefault(emptyList())
        }
    }

    fun makePrompt(): String {
        val request = raw.trim()
        return buildString {
            appendLine("نقش: متخصص ارشد و باتجربه در حوزه $domain.")
            appendLine("وظیفه: درخواست کاربر را دقیق، کاربردی و مرحله‌به‌مرحله انجام بده.")
            appendLine("درخواست اولیه کاربر: $request")
            appendLine()
            appendLine("دستورالعمل‌های اجرا:")
            appendLine("1) سطح تحلیل: $depth.")
            appendLine("2) ابهام‌سنجی: $ambiguity.")
            appendLine("3) هیچ مشخصه، استاندارد، قطعه، API یا نتیجه‌ای را حدس نزن.")
            appendLine("4) اطلاعات تأییدشده، محاسبات، فرض‌ها و موارد نامشخص را از هم جدا کن.")
            appendLine("5) در موضوعات وابسته به اطلاعات روز، منابع معتبر و به‌روز را بررسی و ارجاع بده.")
            appendLine("6) پاسخ را با اصطلاحات فنی دقیق و فارسی روان ارائه کن؛ اصطلاحات تخصصی انگلیسی را در صورت نیاز حفظ کن.")
            appendLine("7) اگر اطلاعات کافی است، از سؤال‌های غیرضروری خودداری کن.")
            if (extra.isNotBlank()) {
                appendLine("دستورهای تکمیلی کاربر: ${extra.trim()}")
            }
            appendLine()
            append("خروجی مورد انتظار: ابتدا مسئله را درست صورت‌بندی کن، سپس تحلیل و نتیجه عملی را ارائه بده.")
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PROMPT ENGINEER PRO", fontWeight = FontWeight.Bold)
                            Text("نسخه ۱.۰ • مستقل و بدون API", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        TextButton(onClick = { showSaved = true }) { Text("ذخیره‌ها") }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("درخواستت را بنویس", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = raw, onValueChange = { raw = it },
                    modifier = Modifier.fillMaxWidth(), minLines = 3,
                    label = { Text("درخواست خام") },
                    placeholder = { Text("مثلاً: نویز برد من زیاد است؛ علت را بررسی کن") }
                )
                Text("حوزه تخصصی")
                var domainExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = domainExpanded, onExpandedChange = { domainExpanded = it }) {
                    OutlinedTextField(
                        value = domain, onValueChange = {}, readOnly = true,
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = domainExpanded) }
                    )
                    ExposedDropdownMenu(expanded = domainExpanded, onDismissRequest = { domainExpanded = false }) {
                        listOf("الکترونیک و طراحی PCB", "نرم‌افزار و برنامه‌نویسی", "تحقیق و تحلیل فنی", "مدیریت و کسب‌وکار", "عمومی").forEach {
                            DropdownMenuItem(text = { Text(it) }, onClick = { domain = it; domainExpanded = false })
                        }
                    }
                }
                Text("عمق تحلیل")
                SingleChoiceRow(depth, listOf("سریع و خلاصه", "متوسط و کاربردی", "عمیق و مهندسی")) { depth = it }
                Text("نحوه برخورد با ابهام")
                SingleChoiceRow(ambiguity, listOf(
                    "اگر ابهام مهمی وجود داشت، قبل از اجرا سؤال کن",
                    "فرض منطقی را اعلام کن و ادامه بده",
                    "همه برداشت‌های محتمل را با گزینه‌ها نشان بده"
                )) { ambiguity = it }
                OutlinedTextField(
                    value = extra, onValueChange = { extra = it },
                    modifier = Modifier.fillMaxWidth(), minLines = 2,
                    label = { Text("دستور تکمیلی (اختیاری)") }
                )
                Button(
                    onClick = { if (raw.isNotBlank()) prompt = makePrompt() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = raw.isNotBlank()
                ) { Text("بهینه‌سازی درخواست") }

                if (prompt.isNotBlank()) {
                    HorizontalDivider()
                    Text("پرامپت بهینه‌شده — قابل ویرایش", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = prompt, onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(), minLines = 10
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                val clip = android.content.ClipData.newPlainText("Optimized prompt", prompt)
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                clipboard.setPrimaryClip(clip)
                            },
                            modifier = Modifier.weight(1f)
                        ) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text("کپی") }
                        Button(
                            onClick = {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, prompt)
                                }
                                context.startActivity(Intent.createChooser(send, "ارسال پرامپت به ChatGPT"))
                            },
                            modifier = Modifier.weight(1f)
                        ) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("ارسال به ChatGPT") }
                    }
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                val updated = (saved + prompt).distinct().takeLast(50)
                                activity.dataStore.edit { it[SAVED_PROMPTS] = JSONArray(updated).toString() }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("ذخیره پرامپت در گوشی") }
                    Text(
                        "نکته: این نسخه پرامپت را به‌صورت محلی و قاعده‌محور می‌سازد. برای تحلیل هوشمند و تشخیص معنایی ابهام، متن را از طریق اشتراک‌گذاری به ChatGPT بفرست.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }

        if (showSaved) {
            AlertDialog(
                onDismissRequest = { showSaved = false },
                title = { Text("پرامپت‌های ذخیره‌شده") },
                text = {
                    Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                        if (saved.isEmpty()) Text("هنوز پرامپتی ذخیره نشده است.")
                        saved.forEachIndexed { index, item ->
                            TextButton(onClick = { prompt = item; showSaved = false }, modifier = Modifier.fillMaxWidth()) {
                                Text("پرامپت ${index + 1}", maxLines = 1)
                            }
                            HorizontalDivider()
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showSaved = false }) { Text("بستن") } },
                dismissButton = {
                    TextButton(onClick = {
                        scope.launch { activity.dataStore.edit { it[SAVED_PROMPTS] = "[]" } }
                    }) { Text("پاک‌کردن همه") }
                }
            )
        }
    }
}

@Composable
private fun SingleChoiceRow(selected: String, options: List<String>, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        options.forEach { option ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                RadioButton(selected = selected == option, onClick = { onSelect(option) })
                Text(option, modifier = Modifier.padding(top = 12.dp))
            }
        }
    }
}
